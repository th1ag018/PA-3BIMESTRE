let nota1 = 8
let nota2 = 6
let media = (nota1 + nota2)/2

if (media >= 9.1) {
    console.log(`MB`);

} else if (7.1 <= media && media <= 9){
    consolo.log(`B`);

} else if (4.1 <= media && media <= 7){
    consolo.log(`R`);

} else {
    console.log(`I`);
}