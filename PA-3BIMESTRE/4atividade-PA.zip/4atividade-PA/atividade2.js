let letra = f;

if (letra === "m") {
    console.log("Seu sexo é Masculino.");

} else if (letra === "f") {
    console.log("Seu sexo é Feminino.");

} else {
    console.log("Sexo inválido.");
}