//Estratégia de melhoria da receita da companhia aérea Asas
//Em resposta à crise econômica, a companhia aérea "Asas" está implementando uma nova estratégia para aumentar a receita, oferecendo voos domésticos e internacionais. A companhia aérea tem diferentes estruturas de preços para diferentes regiões e classes de voo.

let regiao1 = "Norte"
let criancaNEc = 3
let adultoNEc = 9
let criancaNEx = 3
let adultoNEx = 9
let classe = "Executiva"

if (regiao1 === "Norte") {
    console.log(`O destinho escolhido foi ${regiao1}`);
    console.log("");
    console.log(`A quantidade de crianças no vôo é: ${criancaNEc + criancaNEx}`);
    console.log("");
    console.log(`A quantidade de adultos no vôo é ${adultoNEc + adultoNEx}`);
    console.log("");
} else if (classe === "Executiva"){
    console.log(`A classe do vôo é: ${classe}`);
    console.log(`O valor na área executiva vai ser: R$ ${( 2500.00 + (2500.00 / 100 * 2))}`)
} else {
    
}