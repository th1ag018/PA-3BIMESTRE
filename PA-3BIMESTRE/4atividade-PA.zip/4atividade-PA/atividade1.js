let lado1 = 28;
let lado2 = 47;
let lado3 = 36;

if (lado1 === lado2 && lado2 === lado3) {
    console.log(`O triângulo é equilátero`);

} else if (lado1 === lado2 || lado1 === lado3) {
    console.log(`O triângulo é isóscelos`);

} else {
    console.log(`O triângulo é escaleno`);
}